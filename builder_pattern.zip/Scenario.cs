﻿using Ardalis.GuardClauses;
using Industrial.Domain;
using Industrial.Domain.ValueObjects;
using LossAssessment.Domain.Enums;
using LossAssessment.Domain.Exceptions;
using LossAssessment.Domain.LossEstimates.Scenarios.BusinessInterruptionAndInterdependence;
using LossAssessment.Domain.LossEstimates.Scenarios.ProgramCovers;
using LossAssessment.Domain.LossEstimates.Scenarios.PropertyDamages;
using LossAssessment.Domain.LossEstimates.Scenarios.PropertyDamages.Enums;
using LossAssessment.Domain.ValueObjects;
using SiteAssessmentResult.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LossAssessment.Domain.LossEstimates.Scenarios;

public class Scenario : Entity
{
    public string Name { get; private set; }

    public ScenarioType Type { get; }

    public LossType LossType { get; }

    public bool IsDirty { get; private set; }

    public Accumulation Accumulation { get; private set; }

    public ScenarioStatus Status { get; }

    public bool LossPeriodExceedsIndemnityPeriod { get; private set; }

    public virtual ScenarioProgramCover ScenarioProgramCoverAssessment { get; }

    public virtual ScenarioPropertyDamage ScenarioPropertyDamageAssessment { get; }

    public virtual ScenarioBusinessInterruptionAndInterdependence ScenarioBusinessInterruptionAndInterdependenceAssessment { get; }

    public virtual TotalSumsInsured TotalSumsInsured { get; private set; }

    public virtual List<ScenarioBiAttachedFile> ScenarioBiAttachedFiles { get; private set; }

    public virtual ScenarioSitePlan ScenarioSitePlan { get; private set; }

    public virtual ScenarioSummary ScenarioSummary { get; private set; }

    protected Scenario() { }

    private Scenario(ScenarioBuilder builder)
    {
        Guard.Against.Null(builder);
        Guard.Against.NullOrEmpty(builder.Name);
        Guard.Against.Null(builder.ScenarioType);
        Guard.Against.Null(builder.LossType);
        Guard.Against.Null(builder.Currency);
        Guard.Against.Null(builder.CurrencySek);
        Guard.Against.Null(builder.BusinessInterruptionValues);
        Guard.Against.Null(builder.InterdependencyValues);
        Guard.Against.Null(builder.TotalSumsInsured);
        Guard.Against.Null(builder.TotalSumsInsured.LocationSumsInsuredTotal);
        // Not implemented yet
        //Guard.Against.Null(builder.TotalSumsInsured.LocationSumsInsuredBiTotal);
        //Guard.Against.Null(builder.TotalSumsInsured.LocationSumsInsuredInterdependencyTotal);
        Guard.Against.Null(builder.Structures);
        Guard.Against.Null(builder.ProgramCovers);
        Guard.Against.Null(builder.ProgramCoversExchangeRates);

        Id = Guid.NewGuid();

        Accumulation = Accumulation.NotAssessed;
        Status = ScenarioStatus.NotPublished;

        Name = builder.Name;
        LossType = builder.LossType;
        Type = builder.ScenarioType;

        IsDirty = true;

        ScenarioProgramCoverAssessment = ScenarioProgramCover.Create(Id,
            builder.Currency,
            builder.ProgramCovers,
            builder.ProgramCoversExchangeRates);

        ScenarioPropertyDamageAssessment = ScenarioPropertyDamage.Create(Id,
            builder.Currency,
            builder.Structures,
            builder.PropertyDamageDescription,
            builder.TotalSumsInsured.LocationSumsInsuredTotal);

        ScenarioSummary = ScenarioSummary.Create(Id, null, builder.Currency, builder.CurrencySek);

        if (builder.BusinessInterruptionProfitLoss != null && builder.InterdependenceProfitLoss != null)
        {
            ScenarioBusinessInterruptionAndInterdependenceAssessment = ScenarioBusinessInterruptionAndInterdependence.Create(Id,
                builder.BusinessInterruptionProfitLoss,
                builder.InterdependenceProfitLoss);
        }
        else
        {
            ScenarioBusinessInterruptionAndInterdependenceAssessment = ScenarioBusinessInterruptionAndInterdependence.CreateDefault(Id,
                builder.Currency,
                builder.BusinessInterruptionValues,
                builder.InterdependencyValues,
                builder.BusinessInterruptionDescription,
                builder.InterdependencyDescription);
        }

        TotalSumsInsured = builder.TotalSumsInsured;
        ScenarioBiAttachedFiles = builder.BiAttachedFiles;
        ScenarioSitePlan = builder.ScenarioSitePlan;

        UpdateIndemnityPeriodFlag();
        RecalculatePropertyDamageSummary(builder.Currency);
    }

    private Scenario(
        string name,
        ScenarioType scenarioType,
        LossType lossType,
        ScenarioSitePlan scenarioSitePlan,
        Scenario source)
    {
        Id = Guid.NewGuid();
        Name = name;
        Type = scenarioType;
        LossType = lossType;

        Accumulation = source.Accumulation;
        Status = source.Status;
        IsDirty = true;
        
        LossPeriodExceedsIndemnityPeriod = source.LossPeriodExceedsIndemnityPeriod;
        
        ScenarioBiAttachedFiles = source.ScenarioBiAttachedFiles.Select(f => f.Copy()).ToList();
        
        ScenarioBusinessInterruptionAndInterdependenceAssessment = 
            source.ScenarioBusinessInterruptionAndInterdependenceAssessment.CopyForNewScenario(Id);
        ScenarioProgramCoverAssessment = source.ScenarioProgramCoverAssessment.CopyForNewScenario(Id);
        ScenarioPropertyDamageAssessment = source.ScenarioPropertyDamageAssessment.CopyForNewScenario(Id);
        
        ScenarioSitePlan = scenarioSitePlan;
        ScenarioSummary = source.ScenarioSummary.CopyForNewScenario(Id);
        TotalSumsInsured = source.TotalSumsInsured.Copy();
    }

    internal static Scenario Create(ScenarioBuilder builder)
        => new(builder);

    public void AddOrUpdateSiteStructure(Currency currency, Structure structure)
    {
        ScenarioPropertyDamageAssessment.AddOrUpdateStructure(currency, structure);

        RecalculatePropertyDamageSummary(currency);
    }

    public void DeleteSiteStructure(Guid structureId, Currency currency)
    {
        ScenarioPropertyDamageAssessment.DeleteStructure(structureId);

        RecalculatePropertyDamageSummary(currency);
    }

    public void UpdateBusinessInterruptionValues(BusinessInterruptionAndInterdependencyValues businessInterruptionValues)
    {
        ScenarioBusinessInterruptionAndInterdependenceAssessment.UpdateBusinessInterruptionValues(businessInterruptionValues);
        UpdateIndemnityPeriodFlag();
    }

    public void UpdateInterdependencyValues(BusinessInterruptionAndInterdependencyValues interdependencyValues, decimal? businessInterruptionLimit = null)
    {
        ScenarioBusinessInterruptionAndInterdependenceAssessment.UpdateInterdependencyValues(interdependencyValues, businessInterruptionLimit);
    }

    public void RecalculateInterdependencyLoss(decimal? businessInterruptionLimit)
    {
        ScenarioBusinessInterruptionAndInterdependenceAssessment.RecalculateInterdependencyLoss(businessInterruptionLimit);
    }

    public void UpdateScenarioName(string newName)
    {
        Guard.Against.NullOrEmpty(newName);

        Name = newName;
    }

    public void SetTotalSumsInsuredPropertyValueTotal(PropertyValue propertyValueTotal, Currency currency)
    {
        TotalSumsInsured = TotalSumsInsured.Create(
            propertyValueTotal.Copy(),
            TotalSumsInsured.LocationSumsInsuredBiTotal.Copy(),
            TotalSumsInsured.LocationSumsInsuredInterdependencyTotal.Copy());

        RecalculatePropertyDamages();
        RecalculatePropertyDamageSummary(currency);
    }

    public void SetTotalSumsInsuredBiTotal(Money biTotal)
    {
        TotalSumsInsured = TotalSumsInsured.Create(
            TotalSumsInsured.LocationSumsInsuredTotal.Copy(),
            biTotal.Copy(),
            TotalSumsInsured.LocationSumsInsuredInterdependencyTotal.Copy());
    }

    public void SetTotalSumsInsuredInterdependencyTotal(Money interdependencyTotal)
    {
        TotalSumsInsured = TotalSumsInsured.Create(
            TotalSumsInsured.LocationSumsInsuredTotal.Copy(),
            TotalSumsInsured.LocationSumsInsuredBiTotal.Copy(),
            interdependencyTotal.Copy());
    }

    public void UpdateAccumulation(Accumulation accumulation)
    {
        Accumulation = accumulation;
    }

    public PropertyDamage RecalculateSiteStructureDamage(Guid siteStructureDamageId,
        PropertyDamageUpdatedPropertyName propertyName,
        decimal newValue,
        Currency currency)
    {
        var siteStructureDamage = ScenarioPropertyDamageAssessment
            .SiteStructureDamages.SingleOrDefault(d => d.Id == siteStructureDamageId)
                ?? throw new SiteStructureDamageNotFoundException(
                    $"SiteStructureDamageId: {siteStructureDamageId}");

        var recalculatedPd = RecalculatePropertyDamage(propertyName, newValue, siteStructureDamage);
        RecalculatePropertyDamageSummary(currency);

        return recalculatedPd;
    }

    public ScenarioSitePlan GetSitePlan()
    {
        return ScenarioSitePlan;
    }

    public void UpdateSitePlan(ScenarioSitePlan scenarioSitePlan)
    {
        ScenarioSitePlan = scenarioSitePlan;
    }

    public void DeleteSitePlan()
    {
        ScenarioSitePlan = default;
    }

    internal void ApplyExchangeRate(
        ExchangeRate lossEstimateChangeCurrencyExchangeRate,
        Dictionary<string, ExchangeRate> programCoversExchangeRates)
    {
        ScenarioProgramCoverAssessment.ApplyExchangeRates(lossEstimateChangeCurrencyExchangeRate.ToCurrency, programCoversExchangeRates);
        ScenarioPropertyDamageAssessment.ApplyExchangeRate(lossEstimateChangeCurrencyExchangeRate);
        ScenarioBusinessInterruptionAndInterdependenceAssessment.ApplyExchangeRate(lossEstimateChangeCurrencyExchangeRate);
        TotalSumsInsured = TotalSumsInsured.ApplyExchangeRate(lossEstimateChangeCurrencyExchangeRate);

        RecalculatePropertyDamages();
        RecalculatePropertyDamageSummary(lossEstimateChangeCurrencyExchangeRate.ToCurrency);
    }

    public void SetLossDegreeAverage(decimal? averageLoss, BusinessInterruptionInterdependency businessInterruptionInterdependency, decimal? businessInterruptionLimit = null)
    {
        ScenarioBusinessInterruptionAndInterdependenceAssessment.SetLossDegreeAverage(averageLoss, businessInterruptionInterdependency, businessInterruptionLimit);
    }

    public void SetLossDegreePerMonth(BusinessInterruptionInterdependency businessInterruptionInterdependency, decimal? businessInterruptionLimit = null)
    {
        ScenarioBusinessInterruptionAndInterdependenceAssessment.SetLossDegreePerMonth(businessInterruptionInterdependency, businessInterruptionLimit);
    }

    public void UpdateLossPeriod(int? lossPeriod, BusinessInterruptionInterdependency businessInterruptionInterdependency, decimal? businessInterruptionLimit = null)
    {
        ScenarioBusinessInterruptionAndInterdependenceAssessment.UpdateLossPeriod(lossPeriod, businessInterruptionInterdependency, businessInterruptionLimit);

        if (businessInterruptionInterdependency == BusinessInterruptionInterdependency.BusinessInterruption)
        {
            UpdateIndemnityPeriodFlag();
        }
    }

    public void UpdateLossPercentageForMonth(int monthIndex, decimal? loss, BusinessInterruptionInterdependency businessInterruptionInterdependency, decimal? businessInterruptionLimit = null)
    {
        ScenarioBusinessInterruptionAndInterdependenceAssessment.UpdateLossPercentageForMonth(monthIndex, loss, businessInterruptionInterdependency, businessInterruptionLimit);
    }

    public string GetPropertyDamageDescription()
        => ScenarioPropertyDamageAssessment.GetPropertyDamageDescription();

    public void UpdatePropertyDamageDescription(string description)
    {
        ScenarioPropertyDamageAssessment.UpdatePropertyDamageDescription(description);
    }

    public string GetBusinessInterruptionDescription()
        => ScenarioBusinessInterruptionAndInterdependenceAssessment.GetBusinessInterruptionDescription();

    public void UpdateBusinessInterruptionDescription(string description)
    {
        ScenarioBusinessInterruptionAndInterdependenceAssessment.UpdateBusinessInterruptionDescription(description);
    }

    public string GetInterdependencyDescription()
        => ScenarioBusinessInterruptionAndInterdependenceAssessment.GetInterdependencyDescription();

    public void UpdateInterdependencyDescription(string description)
    {
        ScenarioBusinessInterruptionAndInterdependenceAssessment.UpdateInterdependencyDescription(description);
    }

    public string GetRsrComment()
        => ScenarioSummary.RsrComment;

    public void UpdateRsrComment(string comment)
    {
        ScenarioSummary.UpdateRsrComment(comment);
    }

    public TotalLoss GetTotalLoss()
        => ScenarioSummary.TotalLoss;

    public void UpdateTotalLoss(TotalLoss totalLoss)
    {
        ScenarioSummary.UpdateTotalLoss(totalLoss);
    }

    public void ReplaceAttachments(List<ScenarioBiAttachedFile> newAttachments)
    {
        ScenarioBiAttachedFiles.Clear();
        ScenarioBiAttachedFiles.AddRange(newAttachments);
    }

    public void UpdateIndemnityPeriodFlag()
    {
        var lossPeriod = ScenarioBusinessInterruptionAndInterdependenceAssessment.BusinessInterruptionProfitLoss.LossPeriodInMonth;
        var biIndemnityPeriod = ScenarioBusinessInterruptionAndInterdependenceAssessment.BusinessInterruptionProfitLoss.BusinessInterruptionAndInterdependencyValues.IndemnityPeriod;

        LossPeriodExceedsIndemnityPeriod = lossPeriod != null
                                           && lossPeriod > biIndemnityPeriod;
    }

    internal void AddOrUpdateProgramCoverProduct(
        ProgramCoverProduct programCoverProduct,
        Currency lossEstimateCurrency,
        Dictionary<string, ExchangeRate> programCoversExchangeRates)
    {
        ScenarioProgramCoverAssessment.AddOrUpdateProgramCoverProduct(
            programCoverProduct,
            lossEstimateCurrency,
            programCoversExchangeRates);
    }

    internal void DeleteProgramCover(
        string policyNumber,
        string lighthouseLossLimitNumber,
        Currency lossEstimateCurrency,
        Dictionary<string, ExchangeRate> programCoversExchangeRates)
    {
        ScenarioProgramCoverAssessment.DeleteProgramCover(policyNumber, lighthouseLossLimitNumber, lossEstimateCurrency, programCoversExchangeRates);
    }

    internal void UpdateProgramCoverScenarioLossPercentage(
        string policyNumber,
        string lighthouseLossLimitNumber,
        Currency lossEstimateCurrency,
        Percentage percentage,
        Dictionary<string, ExchangeRate> exchangeRates)
    {
        ScenarioProgramCoverAssessment.UpdateScenarioLossPercentage(policyNumber, lighthouseLossLimitNumber,
            lossEstimateCurrency, percentage, exchangeRates);
    }

    internal void UpdateProgramCoversHistoricalExchangeRateValue(List<ExchangeRate> exchangeRates)
    {
        ScenarioProgramCoverAssessment.UpdateProgramCoversHistoricalExchangeRateValue(exchangeRates);
    }

    internal void RemoveProgramCoversHistoricalExchangeRateValue()
    {
        ScenarioProgramCoverAssessment.RemoveProgramCoversHistoricalExchangeRateValue();
    }

    internal void RefreshProgramCoverExchangeRates(Currency lossEstimateCurrency, Dictionary<string, ExchangeRate> exchangeRates)
    {
        ScenarioProgramCoverAssessment.RefreshProgramCoverExchangeRates(lossEstimateCurrency, exchangeRates);
    }

    private void RecalculatePropertyDamageSummary(Currency currency)
    {
        ScenarioPropertyDamageAssessment.UpdatePropertyDamageSummary(
            PropertyDamageSummary.Create(currency,
                ScenarioPropertyDamageAssessment.SiteStructureDamages,
                TotalSumsInsured.LocationSumsInsuredTotal));
    }

    private void RecalculatePropertyDamages()
    {
        foreach (var siteStructureDamage in ScenarioPropertyDamageAssessment.SiteStructureDamages)
        {
            var locationSiTotal = TotalSumsInsured.LocationSumsInsuredTotal?.Total?.Amount ?? 0;
            if (locationSiTotal == 0)
            {
                siteStructureDamage.UpdatePropertyDamage(BigPercentage.Create(0));
                continue;
            }

            var totalPdAmount = siteStructureDamage.PropertyDamage.Total.Money.Amount;

            siteStructureDamage.UpdatePercentage(BigPercentage.Create(totalPdAmount / locationSiTotal));
        }
    }

    private PropertyDamage RecalculatePropertyDamage(PropertyDamageUpdatedPropertyName propertyName,
        decimal newValue, SiteStructureDamage siteStructureDamage)
    {
        var siteStructureSi = siteStructureDamage.Structure.PropertyDamageSumsInsured;

        var pd = siteStructureDamage.PropertyDamage;
        var pdBuildingAmount = pd.Building.Money?.Amount ?? 0m;
        var pdMachineryAmount = pd.Machinery.Money?.Amount ?? 0m;
        var pdStockAmount = pd.Stock.Money?.Amount ?? 0m;
        var pdOtherAmount = pd.Other.Money?.Amount ?? 0m;

        var totalPdAmount = pdBuildingAmount + pdMachineryAmount + pdStockAmount + pdOtherAmount;

        var locationSiTotal = TotalSumsInsured.LocationSumsInsuredTotal.Total.Amount;
        if (locationSiTotal == 0)
        {
            siteStructureDamage.UpdatePropertyDamage(BigPercentage.Create(0));

            return siteStructureDamage.PropertyDamage;
        }

        switch (propertyName)
        {
            case PropertyDamageUpdatedPropertyName.BuildingAmount:
                siteStructureDamage.UpdatePropertyDamage(
                    totalPercentage: BigPercentage.Create((totalPdAmount + newValue - pdBuildingAmount) / locationSiTotal),
                    building: Money.Create(newValue, siteStructureSi.Building.Currency));
                break;

            case PropertyDamageUpdatedPropertyName.MachineryAmount:
                siteStructureDamage.UpdatePropertyDamage(
                    totalPercentage: BigPercentage.Create((totalPdAmount + newValue - pdMachineryAmount) / locationSiTotal),
                    machinery: Money.Create(newValue, siteStructureSi.Machinery.Currency));
                break;

            case PropertyDamageUpdatedPropertyName.StockAmount:
                siteStructureDamage.UpdatePropertyDamage(
                    totalPercentage: BigPercentage.Create((totalPdAmount + newValue - pdStockAmount) / locationSiTotal),
                    stock: Money.Create(newValue, siteStructureSi.Stock.Currency));
                break;

            case PropertyDamageUpdatedPropertyName.OtherAmount:
                siteStructureDamage.UpdatePropertyDamage(
                    totalPercentage: BigPercentage.Create((totalPdAmount + newValue - pdOtherAmount) / locationSiTotal),
                    other: Money.Create(newValue, siteStructureSi.Other.Currency));
                break;

            case PropertyDamageUpdatedPropertyName.BuildingPercent:
                var newPdBuildingAmount = siteStructureSi.Building.Amount * newValue;

                siteStructureDamage.UpdatePercentage(
                    total: BigPercentage.Create((totalPdAmount - pdBuildingAmount + newPdBuildingAmount) / locationSiTotal),
                    building: Percentage.Create(newValue));
                break;

            case PropertyDamageUpdatedPropertyName.MachineryPercent:
                var newPdMachineryAmount = siteStructureSi.Machinery.Amount * newValue;

                siteStructureDamage.UpdatePercentage(
                    total: BigPercentage.Create((totalPdAmount - pdMachineryAmount + newPdMachineryAmount) / locationSiTotal),
                    machinery: Percentage.Create(newValue));
                break;

            case PropertyDamageUpdatedPropertyName.StockPercent:
                var newPdStockAmount = siteStructureSi.Stock.Amount * newValue;

                siteStructureDamage.UpdatePercentage(
                    total: BigPercentage.Create((totalPdAmount - pdStockAmount + newPdStockAmount) / locationSiTotal),
                    stock: Percentage.Create(newValue));
                break;

            case PropertyDamageUpdatedPropertyName.OtherPercent:
                var newPdOtherAmount = siteStructureSi.Other.Amount * newValue;

                siteStructureDamage.UpdatePercentage(
                    total: BigPercentage.Create((totalPdAmount - pdOtherAmount + newPdOtherAmount) / locationSiTotal),
                    other: Percentage.Create(newValue));
                break;

            default:
                throw new ArgumentOutOfRangeException(nameof(propertyName), propertyName, null);
        }

        return siteStructureDamage.PropertyDamage;
    }

    public void MarkAsDirty()
    {
        IsDirty = true;
    }

    public void Confirm()
    {
        IsDirty = false;
    }

    public bool IsValidScenarioLosses()
    {
        return ScenarioProgramCoverAssessment.IsValidScenarioLosses();
    }

    public bool IsValidAccumulation()
    {
        return Accumulation.Id != Accumulation.NotAssessed.Id;
    }

    public bool IsValidBiAndInterdependency()
    {
        var businessInterruption = ScenarioBusinessInterruptionAndInterdependenceAssessment.BusinessInterruptionProfitLoss;
        var interdependency = ScenarioBusinessInterruptionAndInterdependenceAssessment.InterdependencyProfitLoss;

        return businessInterruption.MonthlyDamageDegreesCollection.IsFullyFilledOut &&
            interdependency.MonthlyDamageDegreesCollection.IsFullyFilledOut;
    }

    public bool HasValueInPropertyDamageTotal()
        => ScenarioPropertyDamageAssessment.PropertyDamageSummary.DamageTotal.Total.Money.Amount > 0;

    internal IReadOnlyList<ProgramCoverProduct> GetProgramCoverProducts()
        => ScenarioProgramCoverAssessment.GetProgramCoverProducts();

    internal Scenario CreateWithCopiedData(
        string name,
        ScenarioType scenarioType,
        LossType lossType,
        ScenarioSitePlan scenarioSitePlan)
        => new (name, scenarioType, lossType, scenarioSitePlan, this);
}
