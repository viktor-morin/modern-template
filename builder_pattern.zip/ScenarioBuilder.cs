﻿using Industrial.Domain.ValueObjects;
using LossAssessment.Domain.External;
using LossAssessment.Domain.LossEstimates.Scenarios.BusinessInterruptionAndInterdependence;
using LossAssessment.Domain.LossEstimates.Scenarios.ProgramCovers;
using LossAssessment.Domain.LossEstimates.Scenarios.PropertyDamages;
using LossAssessment.Domain.LossEstimates.Scenarios.ScenarioBuilderHelpers;
using SiteAssessmentResult.Domain.Common;
using System.Collections.Generic;
using System.Linq;

namespace LossAssessment.Domain.LossEstimates.Scenarios;

public class ScenarioBuilder
{
    public ScenarioBuilder(Currency surveyCurrency, Currency currencySek)
    {
        Currency = surveyCurrency;
        CurrencySek = currencySek;
    }

    public string Name { get; private set; }

    public ScenarioType ScenarioType { get; private set; }

    public LossType LossType { get; private set; }

    public Currency Currency { get; private set; }

    /// <summary>
    /// SEK currency (Swedish Krona).
    /// </summary>
    public Currency CurrencySek { get; private set; }

    public BusinessInterruptionAndInterdependencyValues BusinessInterruptionValues { get; private set; }

    public BusinessInterruptionAndInterdependencyValues InterdependencyValues { get; private set; }

    public BusinessInterruptionProfitLoss BusinessInterruptionProfitLoss { get; private set; }

    public InterdependenceProfitLoss InterdependenceProfitLoss { get; private set; }

    public TotalSumsInsured TotalSumsInsured { get; private set; }

    public IEnumerable<StructureData> Structures { get; private set; }

    public List<ProgramCover> ProgramCovers { get; private set; } = [];

    public Dictionary<string, ExchangeRate> ProgramCoversExchangeRates { get; set; } = [];

    public string PropertyDamageDescription { get; private set; }

    public string BusinessInterruptionDescription { get; private set; }

    public string InterdependencyDescription { get; private set; }

    public List<ScenarioBiAttachedFile> BiAttachedFiles { get; private set; } = [];

    public ScenarioSitePlan ScenarioSitePlan { get; private set; }

    public ScenarioBuilder SetName(string name)
    {
        Name = name;
        return this;
    }

    public ScenarioBuilder SetScenarioType(ScenarioType scenarioType)
    {
        ScenarioType = scenarioType;
        return this;
    }

    public ScenarioBuilder SetLossType(LossType lossType)
    {
        LossType = lossType;
        return this;
    }

    public ScenarioBuilder SetBusinessInterruptionAndInterdependencyValuesFromBase(BusinessInterruptionAndInterdependencyValuesBase businessInterruptionAndInterdependencyValuesBase)
    {
        var (businessInterruption, interdependency) = businessInterruptionAndInterdependencyValuesBase.GetBusinessInterruptionAndInterdependencyValues();

        BusinessInterruptionValues = businessInterruption;
        InterdependencyValues = interdependency;

        return this;
    }

    public ScenarioBuilder SetBusinessInterruptionAndInterdependencyValuesFromPreviousScenario(BusinessInterruptionProfitLoss businessInterruptionProfitLoss, InterdependenceProfitLoss interdependencyProfitLoss)
    {
        BusinessInterruptionProfitLoss = businessInterruptionProfitLoss;
        InterdependenceProfitLoss = interdependencyProfitLoss;

        return this;
    }

    public ScenarioBuilder SetLocationSumsInsuredValueTotal(LocationSumsInsuredTotalBase locationSumsInsuredTotalBase)
    {
        TotalSumsInsured = TotalSumsInsured.Create(
            locationSumsInsuredTotalBase.GetLocationSumsInsuredTotal().Copy(),
            TotalSumsInsured?.LocationSumsInsuredBiTotal?.Copy()
                ?? Money.Empty(locationSumsInsuredTotalBase.Building.Currency),
            TotalSumsInsured?.LocationSumsInsuredInterdependencyTotal?.Copy()
                ?? Money.Empty(locationSumsInsuredTotalBase.Building.Currency));
        return this;
    }

    public ScenarioBuilder SetLocationSumsInsuredBiTotal(Money locationSumsInsuredBiTotal)
    {
        TotalSumsInsured = TotalSumsInsured.Create(
            TotalSumsInsured?.LocationSumsInsuredTotal?.Copy()
                ?? PropertyValue.Create(
                    Money.Empty(locationSumsInsuredBiTotal.Currency),
                    Money.Empty(locationSumsInsuredBiTotal.Currency),
                    Money.Empty(locationSumsInsuredBiTotal.Currency),
                    Money.Empty(locationSumsInsuredBiTotal.Currency)),
            locationSumsInsuredBiTotal,
            TotalSumsInsured?.LocationSumsInsuredInterdependencyTotal?.Copy()
                ?? Money.Empty(locationSumsInsuredBiTotal.Currency));
        return this;
    }

    public ScenarioBuilder SetLocationSumsInsuredInterdependencyTotal(Money locationSumsInsuredInterdependencyTotal)
    {
        TotalSumsInsured = TotalSumsInsured.Create(
            TotalSumsInsured?.LocationSumsInsuredTotal?.Copy()
                ?? PropertyValue.Create(
                    Money.Empty(locationSumsInsuredInterdependencyTotal.Currency),
                    Money.Empty(locationSumsInsuredInterdependencyTotal.Currency),
                    Money.Empty(locationSumsInsuredInterdependencyTotal.Currency),
                    Money.Empty(locationSumsInsuredInterdependencyTotal.Currency)),
            TotalSumsInsured?.LocationSumsInsuredBiTotal?.Copy()
                ?? Money.Empty(locationSumsInsuredInterdependencyTotal.Currency),
            locationSumsInsuredInterdependencyTotal);
        return this;
    }

    public ScenarioBuilder SetBuildingsAndStructures(IEnumerable<StructureData> structureData)
    {
        Structures = structureData;
        return this;
    }

    public ScenarioBuilder SetProgramCovers(IEnumerable<ProgramCover> programCovers, Dictionary<string, ExchangeRate> programCoversExchangeRates)
    {
        ProgramCovers = programCovers.ToList();
        ProgramCoversExchangeRates = programCoversExchangeRates;
        return this;
    }


    public ScenarioBuilder SetPropertyDamageDescription(string propertyDamageDescription)
    {
        PropertyDamageDescription = propertyDamageDescription;
        return this;
    }

    public ScenarioBuilder SetBusinessInterruptionDescription(string biDescription)
    {
        BusinessInterruptionDescription = biDescription;
        return this;
    }

    public ScenarioBuilder SetInterdependencyDescription(string interdependencyDescription)
    {
        InterdependencyDescription = interdependencyDescription;
        return this;
    }

    public ScenarioBuilder SetBiAttachedFiles(List<ScenarioBiAttachedFile> biAttachedFiles)
    {
        BiAttachedFiles = biAttachedFiles.Select(b => b.Copy()).ToList();
        return this;
    }

    public ScenarioBuilder SetSitePlan(ScenarioSitePlan scenarioSitePlan)
    {
        ScenarioSitePlan = scenarioSitePlan;
        return this;
    }

    public Scenario Build()
        => Scenario.Create(this);
}
